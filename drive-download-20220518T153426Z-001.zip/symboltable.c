

double x = 3.10;

int main()
{
    int no = 11;


    int arr[3];


    int value = 21;


    int &ref = value;


    int *p = &no;


    return 0;
}