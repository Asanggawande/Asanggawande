// Header file inclusion
#include<stdio.h>

// Macro defination
#define MAX 101

// Function prototype
void fun();

// Structre Declaration
struct Demo
{
    int i;
    int j;
    float f;
};