#include<iostream>
using namespace std;

int main()
{
    int no = 11;
    int &x = no;

    int *p = &x;

    return 0;
}
