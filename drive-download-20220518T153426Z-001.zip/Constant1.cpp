#include<iostream>
using namespace std;

int main()
{
    const int i;        // Error

    const int j = 10;       // Allowed

    return 0;
}