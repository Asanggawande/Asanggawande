#include<stdio.h>

int main()
{
    // Sequance

    printf("Jay Ganesh\n");
    printf("Jay Ganesh\n");
    printf("Jay Ganesh\n");
    printf("Jay Ganesh\n");
    printf("Jay Ganesh\n");

    return 0;
}