static int no = 11;    // Defination of variable
int A = 21;
