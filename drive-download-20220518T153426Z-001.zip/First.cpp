// First.cpp
#include<iostream>

using namespace std;

int main()
{
    cout<<"Jay Ganesh...\n";

    return 0;
}
// GNU      GNU Not UNIX

// g++ First.cpp -o Myexe
// Myexe

// g++ First.cpp -save-temps -o Myexe
// Myexe