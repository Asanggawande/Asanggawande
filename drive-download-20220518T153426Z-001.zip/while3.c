#include<stdio.h>

int main()
{
    int iCnt = 0;

    do
    {
        printf("Jay Ganesh\n");
        iCnt++;
    }while(iCnt < 5);

    return 0;
}