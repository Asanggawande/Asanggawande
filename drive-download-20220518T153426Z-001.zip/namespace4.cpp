#include<iostream>

namespace
{
    void fun()
    {
        std::cout<<"Inside fun\n";
    }
}

int main()
{
    std::cout<<"Jay Ganesh\n";

    fun();
    
    return 0;
}