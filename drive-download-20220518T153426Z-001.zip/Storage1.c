#include <stdio.h>

int X = 51;

void Demo()
{
    int no = 11;
    auto int Data = 21;
    int Y;
    register int A = 51;

}

int main()
{
    int i = 10;
    auto int j = 20;

    Demo();     // Function call

    return 0;
}