#include<stdio.h>

int main()
{


    return 0;
}







int no = 11;


int *x = &no;


int *p = &no;



int **q = &p;



int ***a = &q;



int ****b = &a;


int *****c = &b;
















