#include<stdio.h>

int main()
{
    int iCnt = 0;

    //      1             2              3
    for(iCnt = 0; iCnt < 5; iCnt++)
    {
        printf("Jay Ganesh\n");     // 4
    }

    return 0;
}

// 1    Loop counter initialization
// 2    Loop condition (True/ False)
// 3    Loop counter movement (Increment / Decrement)
// 4    Loop body (Logic)


// 1    2   4   3   2   4   3   2   4   3   2   4   3   2   4   3   2



                        True                                        False






