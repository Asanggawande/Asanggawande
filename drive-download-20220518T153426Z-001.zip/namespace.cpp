#include<iostream>

int main()
{
    std::cout<<"Jay Ganesh\n";

    return 0;
}