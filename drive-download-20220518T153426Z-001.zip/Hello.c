#include<stdio.h>

int I = 11;
int J;

void Demo(int no)
{
    int A = 20;

}

void Hello()
{
    int X = 10;


}

int main()
{
    int A = 30;
    int B;
    return 0;
}