#include<stdio.h>

int j = 20;     // Global variable defination

void fun()
{
    int no = 11;

    printf("Inside fun\n");
}